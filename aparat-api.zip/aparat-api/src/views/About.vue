<template>
  <div class="about alert alert-info">
    <h1>
      This website for test api Aparat
      <img src="../../public/favicon.png" alt="" />
    </h1>
  </div>
</template>
