<template>
  <Form>
    <div v-if="!status" :v-show="!status" class="w-100">
      <h3 class="card-title text-danger">serach user Aparat</h3>
      <input v-model="username" type="text" class="form-control w-100" />
      <button @click="SearchData" class="btn btn-info   my-5 fw-bold fs-5 ">
        Search🔍
      </button>
    </div>
    <div v-else>
      <h1 class="card-title">User information</h1>
      <div v-if="userid" class="d-flex flex-column align-items-center">
        <img class="rounded-circle" :src="`${pic_s}`" alt="" />
        <div class="d-flex text-secondary fw-normal">
          username:
          <p>{{ username }}{{ official == 'yes' ? '✔️' : '' }}</p>
        </div>
        <p class="fw-bold">{{ name }}</p>

        <div class="d-flex align-items-center ">
          <div class="d-flex fw-bold">
            followers:
            <p>{{ !follower_cnt ? '0' : follower_cnt }}</p>
          </div>
          <div class="d-flex fw-bold mx-3">
            following:
            <p>{{ !followed_cnt ? '0' : followed_cnt }}</p>
          </div>
        </div>

        <div class="d-flex">
          userId:
          <p>{{ userid }}</p>
        </div>
      </div>
      <div class="alert alert-danger" v-else>
        user not found! 😔😔
      </div>
      <button class="btn btn-warning" @click="changeshow">back to home</button>
    </div>
  </Form>
</template>

<script>
  // @ is an alias to /src
  import Form from '@/components/Form.vue';
  export default {
    name: 'Home',
    components: { Form },
    data() {
      return {
        username: '',
        status: false,
        pic_s: '',
        userid: '',
        name: '',
        follower_cnt: '',
        followed_cnt: '',
        official: '',
      };
    },
    computed: {
      changeshow() {
        this.status = !this.status;
      },
    },
    methods: {
      SearchData() {
        const Username = this.username;
        const url = `https://www.aparat.com/etc/api/profile/username/${Username}`;
        const axios = require('axios').default;
        axios.get(url).then((response) => {
          const data = response.data.profile;
          const {
            pic_m,
            userid,
            name,
            follower_cnt,
            followed_cnt,
            official,
          } = data;
          this.pic_s = pic_m;
          this.userid = userid;
          this.name = name;
          this.follower_cnt = follower_cnt;
          this.followed_cnt = followed_cnt;
          this.official = official;
        });
        this.status = true;
      },
    },
  };
</script>
<style scoped>
  img {
    width: 8rem;
    height: 8rem;
  }
  button {
    text-transform: capitalize;
  }
</style>
