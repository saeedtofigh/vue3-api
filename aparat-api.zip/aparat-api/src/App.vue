<template>
  <Header></Header>
  <router-view class="container my-5" />
</template>
<script>
  import Header from '@/components/Header.vue';
  export default {
    components: { Header },
  };
</script>
<style>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #000;
    text-transform: capitalize;
  }

  #nav a {
    text-decoration: unset;
    font-weight: bold;
    color: #fff;
    margin-right: 2rem;
  }

  #nav a.router-link-exact-active {
    color: #42b983;
  }
  
</style>
