<template>
  <div
    id="nav"
    class="header bg-dark shadow d-flex align-items-center p-3"
  >
    <img src="@/assets/logo.png" class="mx-3 " alt="" />
    <router-link to="/">Home</router-link>
    <router-link to="/about">About</router-link>
  </div>
</template>
<script>
  export default {
    name: 'Header',
  };
</script>
<style scoped>
  img {
    width: 10rem;
    height: 4rem;
  }
</style>
