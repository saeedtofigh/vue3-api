<template>
  <div class="card shadow w-50 d-flex flex-column align-items-center p-3">
    <slot> </slot>
  </div>
</template>
<script>
  export default {
    name: 'Form',
  };
</script>
